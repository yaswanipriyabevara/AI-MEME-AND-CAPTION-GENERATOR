# Capshun — AI Meme & Social Media Caption Generator

**Upload a photo. Pick a tone. Get scroll-stopping captions in seconds.**

![React](https://img.shields.io/badge/React-19-149ECA?logo=react&logoColor=white)
![Vite](https://img.shields.io/badge/Vite-6-646CFF?logo=vite&logoColor=white)
![TailwindCSS](https://img.shields.io/badge/Tailwind_CSS-3-38B2AC?logo=tailwindcss&logoColor=white)
![Node](https://img.shields.io/badge/Node.js-18%2B-339933?logo=node.js&logoColor=white)
![Express](https://img.shields.io/badge/Express-4-000000?logo=express&logoColor=white)
![Gemini](https://img.shields.io/badge/Google_Gemini-2.0_Flash-8E75FF?logo=googlegemini&logoColor=white)
![Vercel](https://img.shields.io/badge/Deployed_on-Vercel-000000?logo=vercel&logoColor=white)
![Render](https://img.shields.io/badge/Deployed_on-Render-46E3B7?logo=render&logoColor=white)

---

## 1. Problem & Solution

Social media managers and casual creators need to post constantly, but writing a genuinely
funny, on-brand caption for every image is slow and creatively draining — especially across
multiple accounts and platforms. Generic AI writing tools don't understand meme culture, and
manual meme-makers don't help with the writing at all.

**Capshun** closes that gap: upload an image (or just describe a situation), pick a tone and a
target platform, and Gemini's multimodal vision model generates a batch of genuinely distinct
caption options, matching hashtags, and 2–3 recognizable meme formats your content already fits —
all in one request, ready to copy and post.

## 2. Key Features

- 🖼️ **Image upload or text description** — drag-and-drop an image, or just describe the moment
- 🤖 **Multimodal AI understanding** — Gemini reads the actual image content, not just a filename
- 🎭 **4+ tone controls** — Humorous, Professional, Sarcastic, Inspirational, Wholesome, Gen-Z
- 📱 **Platform-aware copy** — Instagram, Twitter/X, LinkedIn, and Reddit each get tailored length and style
- 🔁 **Batch generation** — 5 to 8 genuinely different caption options per request
- 🏷️ **Auto hashtag suggestions** tailored to the platform
- 🧩 **Meme template matching** — matches your content against a curated list of 20 well-known formats
- 📋 **One-click copy** for instant posting
- 🛡️ **Built-in content safety** — Gemini safety settings + explicit prompt guardrails against offensive output

## 3. Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 19, Vite, Tailwind CSS |
| Backend | Node.js, Express, Multer |
| AI | Google Gemini API (`@google/genai`), multimodal vision + text |
| Hosting | Vercel (frontend) · Render (backend) |

## 4. Architecture & Data Flow

```mermaid
flowchart LR
    A[User: image or text] -->|multipart/form-data| B(React + Vite frontend)
    B -->|POST /api/generate/captions| C(Express backend)
    C -->|multer: buffer image| D[Gemini API]
    D -->|captions + hashtags + image summary JSON| C
    C -->|image summary| E[Meme template matcher]
    E -->|Gemini ranks curated list| D
    C -->|final JSON payload| B
    B -->|render sticky-note caption cards| A
```

**Request lifecycle:**
1. User uploads an image and/or types a description, then picks a tone + platform.
2. Frontend sends a `multipart/form-data` request to `POST /api/generate/captions`.
3. Backend validates the file (type/size) via Multer, then calls Gemini with the image bytes
   (base64 inline data) and a tone/platform-specific prompt, requesting strict JSON output.
4. The backend parses Gemini's JSON, then makes a second lightweight Gemini call that ranks the
   curated meme-template list against the image summary.
5. Backend returns captions, hashtags, image summary, and template matches in one JSON response.
6. Frontend renders results as a scrapbook-style grid of caption cards.

## 5. Project Structure

```
ai-meme-caption-generator/
├── frontend/                # React + Vite + Tailwind app
│   ├── src/
│   │   ├── components/      # ImageUpload, ToneSelector, PlatformSelector, CaptionResults, ...
│   │   ├── api/client.js    # fetch wrapper for the backend API
│   │   └── App.jsx
│   ├── vercel.json
│   └── package.json
├── backend/                 # Express + Gemini API
│   ├── routes/generate.js
│   ├── services/geminiService.js
│   ├── middleware/upload.js
│   ├── data/memeTemplates.json
│   ├── render.yaml
│   └── server.js
└── README.md
```

## 6. Local Setup

### Prerequisites
- Node.js 18+
- A Gemini API key from [Google AI Studio](https://aistudio.google.com/app/apikey)

### Step-by-step

```bash
# 1. Clone the repo
git clone <your-repo-url>
cd ai-meme-caption-generator

# 2. Set up the backend
cd backend
npm install
cp .env.example .env
# open .env and paste your GEMINI_API_KEY
npm start
# backend runs on http://localhost:5000

# 3. In a new terminal, set up the frontend
cd frontend
npm install
cp .env.example .env
# VITE_API_BASE_URL=http://localhost:5000 (default is already correct for local dev)
npm run dev
# frontend runs on http://localhost:5173
```

Open `http://localhost:5173`, upload an image (or type a description), pick a tone and platform,
and click **Generate captions**.

### Build for production

```bash
cd frontend
npm run build   # outputs to frontend/dist
```

## 7. Deployment

### Backend → Render
1. Push this repo to GitHub.
2. In Render, create a new **Web Service**, point it at the repo, and set **Root Directory** to `backend`.
3. Render will pick up `render.yaml` automatically (build: `npm install`, start: `npm start`).
4. Add environment variables: `GEMINI_API_KEY`, `CORS_ORIGIN` (your Vercel URL), `GEMINI_MODEL`.

### Frontend → Vercel
1. In Vercel, import the repo and set **Root Directory** to `frontend`.
2. Framework preset: Vite. Vercel will use `vercel.json` for build/output settings.
3. Add environment variable `VITE_API_BASE_URL` = your Render backend URL.
4. Deploy.

## 8. API Reference

### `POST /api/generate/captions`
`multipart/form-data` body:

| Field | Type | Required | Notes |
|---|---|---|---|
| `image` | file | one of `image`/`description` required | JPEG/PNG/WEBP/GIF, max 8MB |
| `description` | string | see above | free-text context |
| `tone` | string | no (default `humorous`) | `humorous`, `professional`, `sarcastic`, `inspirational`, `wholesome`, `genz` |
| `platform` | string | no (default `instagram`) | `instagram`, `twitter/x`, `linkedin`, `reddit` |
| `count` | number | no (default `6`) | 1–8 |

**Response:**
```json
{
  "captions": ["...", "..."],
  "hashtags": ["...", "..."],
  "imageSummary": "one-sentence description of the image",
  "templateMatches": [{ "id": "distracted-boyfriend", "name": "...", "reason": "..." }],
  "meta": { "tone": "humorous", "platform": "instagram", "count": 6 }
}
```

### `GET /api/generate/templates`
Returns the full curated list of 20 meme templates used for matching.

### `GET /api/health`
Basic health check for uptime monitors.

## 9. Known Limitations / Next Steps

- Meme text overlay rendering (baking text directly onto the image with Canvas) is a stretch
  goal not included in this MVP — the app suggests formats but doesn't render them yet.
- No persistence layer (favorites/history) — every session starts fresh, keeping the MVP simple.
- Rate limiting is in-memory and per-instance; swap for a Redis-backed limiter for multi-instance
  production deployments.

---

Built for a hackathon submission. Powered by Google Gemini.
