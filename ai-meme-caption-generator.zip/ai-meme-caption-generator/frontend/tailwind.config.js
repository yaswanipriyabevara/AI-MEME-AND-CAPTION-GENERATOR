/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#14131A",
        "ink-soft": "#2B2A33",
        paper: "#FFF9EE",
        "paper-dim": "#F4EEDE",
        zap: "#FFCB3C",
        punch: "#FF5C4D",
        grape: "#7B5CFA",
        mint: "#37B893",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
        tag: ["'JetBrains Mono'", "monospace"],
      },
      rotate: {
        "-3": "-3deg",
        "-2": "-2deg",
        "2": "2deg",
        "3": "3deg",
      },
      boxShadow: {
        sticker: "6px 6px 0px 0px rgba(20,19,26,1)",
        "sticker-sm": "3px 3px 0px 0px rgba(20,19,26,1)",
      },
    },
  },
  plugins: [],
};
