export default function MemeTemplateSuggestions({ templates }) {
  if (!templates?.length) return null;

  return (
    <div className="mt-10">
      <h2 className="font-display text-2xl font-bold">This fits these formats</h2>
      <p className="mt-1 text-sm text-ink-soft">
        Matched from a curated list of well-known meme templates.
      </p>

      <div className="mt-5 flex gap-4 overflow-x-auto pb-3 scrollbar-thin">
        {templates.map((t) => (
          <div
            key={t.id}
            className="min-w-[240px] max-w-[240px] flex-shrink-0 rounded-2xl border-2 border-ink bg-paper-dim p-4"
          >
            <p className="font-display text-base font-bold">{t.name}</p>
            <p className="mt-2 text-sm text-ink-soft">{t.reason}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
