const PLATFORMS = [
  { id: "instagram", label: "Instagram" },
  { id: "twitter/x", label: "Twitter / X" },
  { id: "linkedin", label: "LinkedIn" },
  { id: "reddit", label: "Reddit" },
];

export default function PlatformSelector({ platform, setPlatform }) {
  return (
    <div>
      <p className="font-display text-sm font-semibold">Platform</p>
      <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {PLATFORMS.map((p) => (
          <button
            key={p.id}
            type="button"
            onClick={() => setPlatform(p.id)}
            className={`rounded-xl border-2 border-ink px-3 py-2 font-display text-sm font-semibold transition-transform hover:-translate-y-0.5 ${
              platform === p.id ? "bg-ink text-paper shadow-sticker-sm" : "bg-white"
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>
    </div>
  );
}
