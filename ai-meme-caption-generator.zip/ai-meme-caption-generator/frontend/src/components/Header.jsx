export default function Header() {
  return (
    <header className="border-b-4 border-ink bg-paper">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 rotate-[-6deg] items-center justify-center rounded-xl border-4 border-ink bg-zap font-display text-xl font-bold shadow-sticker-sm">
            C
          </div>
          <div>
            <p className="font-display text-xl font-bold leading-none">Capshun</p>
            <p className="font-tag text-[11px] leading-none text-ink-soft mt-1">
              caption + meme generator
            </p>
          </div>
        </div>
        <a
          href="https://github.com"
          target="_blank"
          rel="noreferrer"
          className="hidden rounded-lg border-2 border-ink bg-white px-4 py-2 font-display text-sm font-semibold shadow-sticker-sm transition-transform hover:-translate-y-0.5 sm:block"
        >
          View source
        </a>
      </div>
    </header>
  );
}
