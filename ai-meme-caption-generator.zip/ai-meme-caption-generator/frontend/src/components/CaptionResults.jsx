import { useState } from "react";

const NOTE_COLORS = ["bg-zap", "bg-punch text-white", "bg-grape text-white", "bg-mint text-white", "bg-white"];
const ROTATIONS = ["-rotate-2", "rotate-2", "-rotate-3", "rotate-3", "rotate-0"];

export default function CaptionResults({ captions, hashtags, imageSummary }) {
  const [copiedIndex, setCopiedIndex] = useState(null);

  async function handleCopy(caption, index) {
    try {
      await navigator.clipboard.writeText(caption);
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 1500);
    } catch {
      // Clipboard permissions can fail silently in some sandboxed browsers.
    }
  }

  if (!captions?.length) return null;

  return (
    <div className="mt-10">
      <div className="flex items-baseline justify-between">
        <h2 className="font-display text-2xl font-bold">Your captions</h2>
        <span className="font-tag text-xs text-ink-soft">{captions.length} options</span>
      </div>

      {imageSummary && (
        <p className="mt-2 max-w-2xl text-sm text-ink-soft">
          What the AI saw: <span className="italic">"{imageSummary}"</span>
        </p>
      )}

      <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {captions.map((caption, index) => (
          <div
            key={index}
            className={`${NOTE_COLORS[index % NOTE_COLORS.length]} ${ROTATIONS[index % ROTATIONS.length]} flex min-h-[160px] flex-col justify-between rounded-2xl border-4 border-ink p-5 shadow-sticker transition-transform hover:rotate-0 hover:-translate-y-1`}
          >
            <p className="font-body text-base leading-snug">{caption}</p>
            <button
              onClick={() => handleCopy(caption, index)}
              className="mt-4 self-start rounded-lg border-2 border-ink bg-paper px-3 py-1.5 font-display text-xs font-bold text-ink transition-transform hover:-translate-y-0.5"
            >
              {copiedIndex === index ? "Copied!" : "Copy"}
            </button>
          </div>
        ))}
      </div>

      {hashtags?.length > 0 && (
        <div className="mt-8">
          <p className="font-display text-sm font-semibold">Suggested hashtags</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {hashtags.map((tag, i) => (
              <span
                key={i}
                className="rounded-full border-2 border-ink bg-white px-3 py-1 font-tag text-xs"
              >
                #{tag.replace(/^#/, "")}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
