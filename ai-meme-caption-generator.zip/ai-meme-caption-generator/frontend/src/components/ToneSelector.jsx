const TONES = [
  { id: "humorous", label: "Humorous", color: "bg-zap" },
  { id: "professional", label: "Professional", color: "bg-mint" },
  { id: "sarcastic", label: "Sarcastic", color: "bg-punch" },
  { id: "inspirational", label: "Inspirational", color: "bg-grape" },
  { id: "wholesome", label: "Wholesome", color: "bg-zap" },
  { id: "genz", label: "Gen-Z", color: "bg-punch" },
];

export default function ToneSelector({ tone, setTone }) {
  return (
    <div>
      <p className="font-display text-sm font-semibold">Tone</p>
      <div className="mt-2 flex flex-wrap gap-2">
        {TONES.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTone(t.id)}
            className={`rounded-full border-2 border-ink px-4 py-1.5 font-display text-sm font-semibold transition-transform hover:-translate-y-0.5 ${
              tone === t.id ? `${t.color} shadow-sticker-sm` : "bg-white"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>
    </div>
  );
}
