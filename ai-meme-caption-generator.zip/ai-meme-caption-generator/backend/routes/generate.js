import { Router } from "express";
import { upload } from "../middleware/upload.js";
import {
  generateCaptions,
  suggestMemeTemplates,
  getAllMemeTemplates,
} from "../services/geminiService.js";

const router = Router();

const VALID_TONES = ["humorous", "professional", "sarcastic", "inspirational", "wholesome", "genz"];
const VALID_PLATFORMS = ["instagram", "twitter/x", "twitter", "linkedin", "reddit", "tiktok"];

router.post("/captions", upload.single("image"), async (req, res) => {
  try {
    const { description, tone, platform, count } = req.body;

    const normalizedTone = (tone || "humorous").toLowerCase();
    const normalizedPlatform = (platform || "instagram").toLowerCase();
    const requestedCount = Math.min(Math.max(parseInt(count, 10) || 6, 1), 8);

    if (!req.file && (!description || !description.trim())) {
      return res.status(400).json({
        error: "Please upload an image or describe the situation so the AI has something to work with.",
      });
    }

    if (tone && !VALID_TONES.includes(normalizedTone)) {
      return res.status(400).json({ error: `Unsupported tone. Choose one of: ${VALID_TONES.join(", ")}` });
    }

    if (platform && !VALID_PLATFORMS.includes(normalizedPlatform)) {
      return res.status(400).json({ error: `Unsupported platform. Choose one of: ${VALID_PLATFORMS.join(", ")}` });
    }

    const captionResult = await generateCaptions({
      imageBuffer: req.file ? req.file.buffer : null,
      mimeType: req.file ? req.file.mimetype : null,
      description: description ? description.trim() : "",
      tone: normalizedTone,
      platform: normalizedPlatform,
      count: requestedCount,
    });

    let templateMatches = [];
    try {
      templateMatches = await suggestMemeTemplates({
        description: description ? description.trim() : "",
        imageSummary: captionResult.imageSummary,
      });
    } catch (templateError) {
      console.error("Meme template suggestion failed (non-fatal):", templateError.message);
    }

    return res.json({
      captions: captionResult.captions,
      hashtags: captionResult.hashtags,
      imageSummary: captionResult.imageSummary,
      templateMatches,
      meta: {
        tone: normalizedTone,
        platform: normalizedPlatform,
        count: requestedCount,
      },
    });
  } catch (error) {
    console.error("Caption generation error:", error);
    const status = error.message?.includes("GEMINI_API_KEY") ? 500 : 502;
    return res.status(status).json({
      error: error.message || "Something went wrong while generating captions. Please try again.",
    });
  }
});

router.get("/templates", (req, res) => {
  res.json({ templates: getAllMemeTemplates() });
});

export default router;
